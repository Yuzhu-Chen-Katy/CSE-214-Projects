// Yuzhu Chen 113516748 R04
public class HoldingQueue extends VirtualLine{
	private int maxSize;

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public int getMaxSize() {
		return maxSize;
	}
}
