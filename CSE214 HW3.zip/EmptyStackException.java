
public class EmptyStackException extends Exception {
	public EmptyStackException(String error) {
		super(error);
	}

}
