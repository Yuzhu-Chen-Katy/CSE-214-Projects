
public class EndOfListException extends Exception{
	public EndOfListException(String error) {
		super(error);
	}

}
