//Yuzhu Chen 113516748 R04
public class DeanException extends Exception {
	public DeanException(String msg) {
		super(msg);
	}

}
