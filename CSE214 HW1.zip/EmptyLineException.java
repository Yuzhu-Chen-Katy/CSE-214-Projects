//Yuzhu Chen 113516748 R04
public class EmptyLineException extends Exception {
	public EmptyLineException(String msg) {
		super(msg);
	}

}
