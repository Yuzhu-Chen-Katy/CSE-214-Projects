
public class FullStackException extends Exception {
	public FullStackException(String error) {
		super(error);
	}

}
